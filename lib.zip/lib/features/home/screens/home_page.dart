import 'package:flutter/material.dart';
import 'package:mini_nft_marketplace/core/resources/color_manager.dart';
import 'package:mini_nft_marketplace/core/resources/size_manager.dart';
import 'package:mini_nft_marketplace/core/resources/string_manager.dart';
import 'package:mini_nft_marketplace/features/home/screens/home.dart';
import 'package:mini_nft_marketplace/features/home/widgets/custom_bottom_navigation_bar.dart';
import 'package:mini_nft_marketplace/features/home/widgets/custom_title_home_page.dart';
import 'package:mini_nft_marketplace/features/search/screens/search_page.dart';
import 'package:mini_nft_marketplace/features/state/screens/state_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  List<Widget> w = [Home(), StatePage(),SearchPage()];

  @override
  Widget build(BuildContext context) {
    double widthScreen = MediaQuery.of(context).size.width;
    return Scaffold(
      extendBody: true,
      bottomNavigationBar: CustomBottomNavigationBar(
        onPressedHome: () {
          index = 0;
          setState(() {});
        },
        onPressedState: () {
          index = 1;
          setState(() {});
        },onPressedSearch: () {
          index = 2;
          setState(() {});
        },onPressedPerson: () {
          index = 3;
          setState(() {});
        },
        widthScreen: widthScreen,
      ),
      appBar: index == 0
          ? AppBar(
              title: CustomTitleHomePage(),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            )
          : index == 1
          ? AppBar(
              title: Text(
                StringManager.stats,
                style: TextStyle(
                  color: ColorManager.kColorWhite,
                  fontSize: FontSizeValues.fs25,
                  fontWeight: FontWeight.bold,
                ),
              ),
              actions: [
                Padding(
                  padding: const EdgeInsets.only(right: PaddingValues.p16),
                  child: IconButton(onPressed: () {

                  }, icon: Icon(Icons.more_horiz_rounded,color: ColorManager.kColorWhite,),)
                ),
              ],
              backgroundColor: Colors.transparent,
              centerTitle: true,
            )
          : AppBar(title: Text("null")),
      backgroundColor: ColorManager.kColorPrimary,
      body: w[index],
    );
  }
}
