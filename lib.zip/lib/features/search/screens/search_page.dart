import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:mini_nft_marketplace/core/resources/color_manager.dart';
import 'package:mini_nft_marketplace/core/resources/size_manager.dart';
import 'package:mini_nft_marketplace/features/search/widgets/custom_table_row_search_page.dart';
import 'package:mini_nft_marketplace/models/table_row_model2.dart';

class SearchPage extends StatelessWidget {
  const SearchPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorManager.kColorPrimary,
      body: SafeArea(
        child: Container(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: [
              TextFormField(
                textInputAction: TextInputAction.send,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: ColorManager.kColorPrimary,
                  labelStyle: TextStyle(color: ColorManager.kColorWhite),
                  labelText: "Search OpenSea",
                  hintFadeDuration: Duration(seconds: 5),
                ),
              ),
              SizedBox(height: 15,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(
                    width: 50,
                    height: 30,
                    color: ColorManager.kColorGray350?.withValues(alpha: 0.2),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Icon(
                          Icons.all_out,
                          color: ColorManager.kColorWhite,
                          size: 15,
                        ),
                        Text(
                          "All",
                          style: TextStyle(
                            color: ColorManager.kColorWhite,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 100,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Icon(
                          Icons.collections,
                          color: ColorManager.kColorWhite,
                          size: 15,
                        ),
                        Text(
                          "Collections",
                          style: TextStyle(
                            color: ColorManager.kColorWhite,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 70,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Icon(
                          Icons.currency_bitcoin_sharp,
                          color: ColorManager.kColorWhite,
                          size: 15,
                        ),
                        Text(
                          "Coins",
                          style: TextStyle(
                            color: ColorManager.kColorWhite,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 80,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Icon(
                          Icons.image_outlined,
                          color: ColorManager.kColorWhite,
                          size: 15,
                        ),
                        Text(
                          "Images",
                          style: TextStyle(
                            color: ColorManager.kColorWhite,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10,),
              Container(
                decoration: BoxDecoration(
                  border: Border(bottom: BorderSide(color: ColorManager.kColorWhite,width: WidthValues.w0_2)),
                ),
              ),
              SizedBox(height: 10,),
              Row(
                children: [
                  Text("TRENDING COLLECTION",style: TextStyle(color: ColorManager.kColorGray350),textAlign: TextAlign.start,),
                ],
              ),
              SizedBox(height: 15,),
                  ClipRRect(
                    borderRadius: BorderRadiusGeometry.circular(20),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(
                        sigmaX: BlurValues.b10,
                        sigmaY: BlurValues.b10,
                      ),
                      child: Container(
                        // color: ColorManager.kColorWhite.withValues(alpha: 0.1),
                        height: 358,
                        padding: EdgeInsets.symmetric(horizontal: 9, vertical: 16),
                        child: ListView(
                          children: [
                            CustomTableRowStatePage(tableRowModel2: TableRowModel2( "assets/images/table5.jpg","Cash Cats" , 138.36, "+45%", true)),
                            CustomTableRowStatePage(tableRowModel2: TableRowModel2( "assets/images/table5.jpg","Cash Cats" , 138.36, "+45%", true)),
                            CustomTableRowStatePage(tableRowModel2: TableRowModel2( "assets/images/table5.jpg","Cash Cats" , 138.36, "+45%", true)),
                            CustomTableRowStatePage(tableRowModel2: TableRowModel2( "assets/images/table5.jpg","Cash Cats" , 138.36, "+45%", true)),
                            CustomTableRowStatePage(tableRowModel2: TableRowModel2( "assets/images/table5.jpg","Cash Cats" , 138.36, "+45%", true)),
                            CustomTableRowStatePage(tableRowModel2: TableRowModel2( "assets/images/table5.jpg","Cash Cats" , 138.36, "+45%", true)),
                            CustomTableRowStatePage(tableRowModel2: TableRowModel2( "assets/images/table5.jpg","Cash Cats" , 138.36, "+45%", true)),
                            CustomTableRowStatePage(tableRowModel2: TableRowModel2( "assets/images/table5.jpg","Cash Cats" , 138.36, "+45%", true)),
                          ],
                        ),
                      ),
                    ),
                  ),
            ],
          ),
        ),
      ),
    );
  }
}
